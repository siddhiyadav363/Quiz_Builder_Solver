package siddhiyadav363atgmail.com.quizbuildersolver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity  {

    private FirebaseAuth auth;

    private Button login,register;

    private EditText userMail;
    private EditText password;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        auth = FirebaseAuth.getInstance();

        login = findViewById(R.id.btnStart);
        register = findViewById(R.id.btn_register);

        userMail = findViewById(R.id.editTestIdUserName);
        password = findViewById(R.id.editTestIdPassword);

        login.setOnClickListener(view -> {

            String email= userMail.getText().toString();
            String pass=password.getText().toString();


            if(!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

                if(!pass.isEmpty()) {

                    auth.signInWithEmailAndPassword(email,pass)
                            .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                @Override
                                public void onSuccess(AuthResult authResult) {
                                    Toast.makeText(MainActivity.this,"Login Successfully ",Toast.LENGTH_LONG).show();
                                    startActivity(new Intent(MainActivity.this,ActivityChoice.class));
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(MainActivity.this,"Login UnSuccessfully ",Toast.LENGTH_LONG).show();
                                    Toast.makeText(MainActivity.this,"Check your Data connection ",Toast.LENGTH_LONG).show();
                                }
                            });
                } else {
                  password.setError("Password cannot be empty");
                }
            }
            else if(email.isEmpty()) {
                userMail.setError("Email cannot be Empty ");
            }
            else {
                userMail.setError("Please Enter valid email");
            }

        });

        register.setOnClickListener(view -> startActivity(new Intent(MainActivity.this,ActivityRegister.class)));

    }
}

