package siddhiyadav363atgmail.com.quizbuildersolver;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class myResultActivity extends AppCompatActivity {

    TextView tvResult;
    Button btnFinish;

    Intent intent;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_result);

        tvResult=findViewById(R.id.tvResult);
        btnFinish=findViewById(R.id.btnFinish);

        intent=getIntent();

        int ans=intent.getIntExtra("correct",0);
        tvResult.setText("Your Score is "+ans+" out of 5");

        btnFinish.setOnClickListener(view -> {
            startActivity(new Intent(myResultActivity.this,MainActivity.class));
            finish();
        });

    }


}