package siddhiyadav363atgmail.com.quizbuildersolver;

public class Modelclass {

    /*private String correctOption;
    private String OptionD;
    private String OptionA;
    private String OptionC;
    private String OptionB;
    private String Question;

    public Modelclass() {

    }

    public Modelclass(String correctOption, String optionD, String optionA, String optionC, String optionB, String question) {
        this.correctOption = correctOption;
        OptionD = optionD;
        OptionA = optionA;
        OptionC = optionC;
        OptionB = optionB;
        Question = question;
    }

    public String getCorrectOption() {
        return correctOption;
    }

    public void setCorrectOption(String correctOption) {
        this.correctOption = correctOption;
    }

    public String getOptionD() {
        return OptionD;
    }

    public void setOptionD(String optionD) {
        OptionD = optionD;
    }

    public String getOptionA() {
        return OptionA;
    }

    public void setOptionA(String optionA) {
        OptionA = optionA;
    }

    public String getOptionC() {
        return OptionC;
    }

    public void setOptionC(String optionC) {
        OptionC = optionC;
    }

    public String getOptionB() {
        return OptionB;
    }

    public void setOptionB(String optionB) {
        OptionB = optionB;
    }

    public String getQuestion() {
        return Question;
    }

    public void setQuestion(String question) {
        Question = question;
    }*/
}
