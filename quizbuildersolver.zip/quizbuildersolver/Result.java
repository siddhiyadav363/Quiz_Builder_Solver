package siddhiyadav363atgmail.com.quizbuildersolver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Result extends AppCompatActivity {


    TextView resultDisplay;
    Button finish;



    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        resultDisplay=findViewById(R.id.tvResult);
        finish=findViewById(R.id.btnFinish);

        //ans=getIntent().getStringExtra("correct");

        //int ans=getIntent().getIntExtra("correct",10);

        //resultDisplay.setText("Your Score is "+ans+" out of 5");

        finish.setOnClickListener(view -> {
            startActivity(new Intent(Result.this,MainActivity.class));
            finish();
        });


    }


}