package siddhiyadav363atgmail.com.quizbuildersolver;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityChoice extends AppCompatActivity {

    private Button SetQuiz;
    private Button AttemptQuiz;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);

        SetQuiz = findViewById(R.id.btnBuildQuiz);
        AttemptQuiz = findViewById(R.id.btnAttemptQuiz);

       AttemptQuiz.setOnClickListener(view -> {
           Intent k = new Intent(getApplicationContext(),QuizSolverActivity.class);
           startActivity(k);
       });

       SetQuiz.setOnClickListener(view -> {
           Intent j=new Intent(getApplicationContext(),ActivitySetQuiz.class);
           startActivity(j);
       });



    }
}