package siddhiyadav363atgmail.com.quizbuildersolver.Model;

public class Question {

    private String correctAns,OptionD,optionA,optionC,OptionB,ques;

    private Question(String correctAns, String optionD, String optionA, String optionC, String optionB, String ques) {
        this.correctAns = correctAns;
        this.OptionD = optionD;
        this.optionA = optionA;
        this.optionC = optionC;
        this.OptionB = optionB;
        this.ques = ques;
    }

    private Question() {

    }

    public String getCorrectAns() {
        return correctAns;
    }

    public void setCorrectAns(String correctAns) {
        this.correctAns = correctAns;
    }

    public String getOptionD() {
        return OptionD;
    }

    public void setOptionD(String optionD) {
        OptionD = optionD;
    }

    public String getOptionA() {
        return optionA;
    }

    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }

    public String getOptionC() {
        return optionC;
    }

    public void setOptionC(String optionC) {
        this.optionC = optionC;
    }

    public String getOptionB() {
        return OptionB;
    }

    public void setOptionB(String optionB) {
        OptionB = optionB;
    }

    public String getQues() {
        return ques;
    }

    public void setQues(String ques) {
        this.ques = ques;
    }
}
