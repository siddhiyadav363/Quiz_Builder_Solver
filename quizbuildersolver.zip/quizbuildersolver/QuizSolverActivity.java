package siddhiyadav363atgmail.com.quizbuildersolver;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.concurrent.TimeUnit;

import siddhiyadav363atgmail.com.quizbuildersolver.Model.Question;

public class QuizSolverActivity extends AppCompatActivity {

    Button optionA,optionB,optionC,optionD;
    TextView question,quizTimer;

    int total=0;
    int correct=0;
    int wrong=0;
    int correctCount=0;

    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_solver2);

        QuizTimer();

        optionA = findViewById(R.id.btnOptA);
        optionB = findViewById(R.id.btnOptB);
        optionC = findViewById(R.id.btnOptC);
        optionD = findViewById(R.id.btnOptD);
        //submit = findViewById(R.id.btnSubmitResult);

        question = findViewById(R.id.tvQuestion);
        quizTimer = findViewById(R.id.quizTimer);

        updateQuestion();

    }

    private void updateQuestion() {

        total++;

        if(total > 5) {

            Intent intent;
            intent=new Intent(getApplicationContext(),Result.class);
            intent.putExtra("correct",correctCount);
            startActivity(intent);
            finish();
        }
        else {
            reference = FirebaseDatabase.getInstance().getReference().child("quizQuestion").child(String.valueOf(total));
            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Question questionObj = dataSnapshot.getValue(Question.class);

                    String que=dataSnapshot.child("question").getValue(String.class);
                    String correctOpt = dataSnapshot.child("correctOption").getValue(String.class);
                    String option1 = dataSnapshot.child("optionOne").getValue(String.class);
                    String option2 = dataSnapshot.child("optionTwo").getValue(String.class);
                    String option3 = dataSnapshot.child("optionThree").getValue(String.class);
                    String option4 = dataSnapshot.child("optionFour").getValue(String.class);


                    question.setText(que);
                    optionA.setText(option1);
                    optionB.setText(option2);
                    optionC.setText(option3);
                    optionD.setText(option4);


                    Log.d("myData","Question-> "+que);
                    Log.d("myData","Question-> "+correctOpt);
                    Log.d("myData","Question-> "+option1);
                    Log.d("myData","Question-> "+option2);
                    Log.d("myData","Question-> "+option3);
                    Log.d("myData","Question-> "+option4);

                    optionA.setOnClickListener(view -> {

                        if(optionA.getText().toString().equals(correctOpt)) {
                            //optionA.setBackgroundColor(R.color.green);
                            correct++;

                            correctCount++;

                            Handler handler = new Handler();
                            handler.postDelayed(() -> {
                                //correct++;
                                //optionA.setBackgroundColor(R.color.defaultButton);
                                updateQuestion();
                            },150);
                        }
                        else {
                            wrong++;
                            /*optionA.setBackgroundColor(R.color.red);

                            if(optionB.getText().toString().equals(questionObj.getCorrectAns())) {
                                optionB.setBackgroundColor(R.color.green);
                            }
                            else if (optionC.getText().toString().equals(questionObj.getCorrectAns())) {
                                optionC.setBackgroundColor(R.color.green);
                            }
                            else if (optionD.getText().toString().equals(questionObj.getCorrectAns())) {
                                optionD.setBackgroundColor(R.color.green);
                            }*/

                            Handler handler = new Handler();
                            handler.postDelayed(() -> {
                                /*optionA.setBackgroundColor(R.color.defaultButton);
                                optionB.setBackgroundColor(R.color.defaultButton);
                                optionC.setBackgroundColor(R.color.defaultButton);
                                optionD.setBackgroundColor(R.color.defaultButton);*/
                                updateQuestion();
                            },150);

                        }
                    });

                    optionB.setOnClickListener(view -> {
                        if(optionB.getText().toString().equals(correctOpt)) {

                            correctCount++;

                            correct++;
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @SuppressLint("ResourceAsColor")
                                @Override
                                public void run() {

                                    updateQuestion();
                                }
                            },150);
                        }else {
                            wrong++;


                            Handler handler = new Handler();
                            handler.postDelayed(() -> {

                                updateQuestion();
                            },150);

                        }
                    });

                    optionC.setOnClickListener(view -> {
                        if(optionC.getText().toString().equals(correctOpt)) {

                            correct++;

                            correctCount++;

                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @SuppressLint("ResourceAsColor")
                                @Override
                                public void run() {
                                    updateQuestion();
                                }
                            },150);
                        }else {
                            wrong++;

                            Handler handler = new Handler();
                            handler.postDelayed(() -> {
                                updateQuestion();
                            },150);

                        }
                    });

                    optionD.setOnClickListener(view -> {
                        if(optionD.getText().toString().equals(correctOpt)) {

                            correct++;

                            correctCount++;

                            Handler handler = new Handler();
                            handler.postDelayed(() -> {
                                updateQuestion();
                            },150);
                        }else {
                            wrong++;

                            Handler handler = new Handler();
                            handler.postDelayed(() -> {
                                updateQuestion();
                            },150);
                        }
                    });
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });
        }

        Log.d("Correct ans ","correct"+correct);
        Log.d("wrong ans ","correct"+wrong);

    }

    private void QuizTimer() {
        new CountDownTimer(600000, 1000) {
            @SuppressLint({"DefaultLocale", "SetTextI18n"})
            public void onTick(long millisUntilFinished) {
                quizTimer.setText(""+String.format("%d min, %d sec",
                        TimeUnit.MILLISECONDS.toMinutes( millisUntilFinished),
                        TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
            }
            @SuppressLint("SetTextI18n")
            public void onFinish() {
                quizTimer.setText("done!");
                //intent.putExtra("correct",String.valueOf(correct));
                //startActivity(new Intent(getApplicationContext(),Result.class));
                //finish();
            }
        }.start();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}