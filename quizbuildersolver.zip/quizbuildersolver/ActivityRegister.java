package siddhiyadav363atgmail.com.quizbuildersolver;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class ActivityRegister extends AppCompatActivity  {

    private FirebaseAuth auth;
    private EditText signupEmail, signupPassword ,userName;
    private Button signupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        auth = FirebaseAuth.getInstance();

        signupEmail = findViewById(R.id.EditText_Email);
        signupPassword = findViewById(R.id.EditText_password);
        userName = findViewById(R.id.EditText_Name);

        signupButton = findViewById(R.id.btnRegister);


        signupButton.setOnClickListener(view -> {

            String user = signupEmail.getText().toString().trim();
            String pass = signupPassword.getText().toString().trim();
            String userN = userName.getText().toString().trim();

            if(user.isEmpty()) {
                signupEmail.setError("Email cannot be empty");
            }
            if(pass.isEmpty()) {
                signupPassword.setError("Password cannot be empty");
            }
            else {
                auth.createUserWithEmailAndPassword(user,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(ActivityRegister.this,userN+" Register Successfully ",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(ActivityRegister.this,MainActivity.class));
                        }
                        else {
                            Toast.makeText(ActivityRegister.this,"Register Failed !!! ",Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }

        });

    }

}