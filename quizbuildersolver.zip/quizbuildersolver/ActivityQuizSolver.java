package siddhiyadav363atgmail.com.quizbuildersolver;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.xml.sax.ErrorHandler;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class ActivityQuizSolver extends AppCompatActivity {

    /*DatabaseReference databaseReference;
    ArrayList<Modelclass> list;

    TextView quizTimer;
    TextView Question,Option1,Option2,Option3,Option4;
    CardView cardOfA,cardOfB,cardOfC,cardOfD;
    Button submit;

    Modelclass modelclass;

    int index=0;
    int correctCount=0;
    int wrongCount=0;*/

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_solver);

        /*quizTimer = findViewById(R.id.quizTimer);
        submit = findViewById(R.id.btnNext);

        Question = findViewById(R.id.tvQuestion);
        Option1 = findViewById(R.id.Option1);
        Option2 = findViewById(R.id.Option2);
        Option3 = findViewById(R.id.Option3);
        Option4 = findViewById(R.id.Option4);

        cardOfA = findViewById(R.id.cvOpt1);
        cardOfB = findViewById(R.id.cvOpt2);
        cardOfC = findViewById(R.id.cvOpt3);
        cardOfD = findViewById(R.id.cvOpt4);

        list = new ArrayList<>();

        DatabaseReference rootRef = FirebaseDatabase.getInstance().getReference();
        DatabaseReference quizRef = rootRef.child("quizQuestion");
        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                for (DataSnapshot ds : dataSnapshot.getChildren()) {

                    String que = ds.child("question").getValue(String.class);
                    String correctOpt = ds.child("correctOption").getValue(String.class);
                    String option1 = ds.child("optionOne").getValue(String.class);
                    String option2 = ds.child("optionTwo").getValue(String.class);
                    String option3 = ds.child("optionThree").getValue(String.class);
                    String option4 = ds.child("optionFour").getValue(String.class);

                    Modelclass modelclass = new Modelclass(correctOpt, option4, option1, option3, option2, que);
                    list.add(modelclass);

                }

                Log.d("data","Question in list 1=>"+list.get(0).getQuestion());
                Log.d("data","opt A in list 1=>"+list.get(0).getOptionA());
                Log.d("data","opt B in list 1=>"+list.get(0).getOptionB());
                Log.d("data","opt C in list 1=>"+list.get(0).getOptionC());
                Log.d("data","opt D in list 1=>"+list.get(0).getOptionD());
                Log.d("data","correct opt  in list 1=>"+list.get(0).getCorrectOption()+"\n\n");

                Log.d("data","Question in list 2=>"+list.get(1).getQuestion());
                Log.d("data","opt A in list 2=>"+list.get(1).getOptionA());
                Log.d("data","opt B in list 2=>"+list.get(1).getOptionB());
                Log.d("data","opt C in list 2=>"+list.get(1).getOptionC());
                Log.d("data","opt D in list 2=>"+list.get(1).getOptionD());
                Log.d("data","correct opt  in list 2=>"+list.get(1).getCorrectOption()+"\n\n");

                Log.d("data","Question in list 3=>"+list.get(2).getQuestion());
                Log.d("data","opt A in list 3=>"+list.get(2).getOptionA());
                Log.d("data","opt B in list 3=>"+list.get(2).getOptionB());
                Log.d("data","opt C in list 3=>"+list.get(2).getOptionC());
                Log.d("data","opt D in list 3=>"+list.get(2).getOptionD());
                Log.d("data","correct opt  in list 3=>"+list.get(2).getCorrectOption()+"\n\n");

                Log.d("data","Question in list 4=>"+list.get(3).getQuestion());
                Log.d("data","opt A in list 4=>"+list.get(3).getOptionA());
                Log.d("data","opt B in list 4=>"+list.get(3).getOptionB());
                Log.d("data","opt C in list 4=>"+list.get(3).getOptionC());
                Log.d("data","opt D in list 4=>"+list.get(3).getOptionD());
                Log.d("data","correct opt  in list 4=>"+list.get(3).getCorrectOption()+"\n\n");

                Log.d("data","Question in list 5=>"+list.get(4).getQuestion());
                Log.d("data","opt A in list 5=>"+list.get(4).getOptionA());
                Log.d("data","opt B in list 5=>"+list.get(4).getOptionB());
                Log.d("data","opt C in list 5=>"+list.get(4).getOptionC());
                Log.d("data","opt D in list 5=>"+list.get(4).getOptionD());
                Log.d("data","correct opt  in list 5=>"+list.get(4).getCorrectOption()+"\n\n");

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.d(TAG, databaseError.getMessage());
            }
        };

        quizRef.addValueEventListener(valueEventListener);



        modelclass =list.get(index);

        //resetColor();

        //submit.setClickable(false);

        //QuizTimer();
        //setAllData();*/


    }


    /*public void enableButton() {
        cardOfA.setClickable(true);
        cardOfB.setClickable(true);
        cardOfC.setClickable(true);
        cardOfD.setClickable(true);
    }

    public void disableButton() {
        cardOfA.setClickable(false);
        cardOfB.setClickable(false);
        cardOfC.setClickable(false);
        cardOfD.setClickable(false);
    }

    public void resetColor() {
        cardOfA.setBackgroundColor(getResources().getColor(R.color.white));
        cardOfB.setBackgroundColor(getResources().getColor(R.color.white));
        cardOfC.setBackgroundColor(getResources().getColor(R.color.white));
        cardOfD.setBackgroundColor(getResources().getColor(R.color.white));
    }

    public void Correct(CardView cardOfS) {

        cardOfS.setCardBackgroundColor(getResources().getColor(R.color.green));

        submit.setOnClickListener(view -> {
            correctCount++;
            index++;
            modelclass = list.get(index);
            resetColor();
            setAllData();
            enableButton();
        });


    }

    public void Wrong(CardView cardOfS) {

        cardOfS.setCardBackgroundColor(getResources().getColor(R.color.red));

        submit.setOnClickListener(view -> {
            wrongCount++;
            if(index<list.size()-1) {
                index++;
                modelclass = list.get(index);
                resetColor();
                setAllData();
                enableButton();
            }
            else {
                GameWon();
            }
        });

    }

    private void GameWon() {
        startActivity(new Intent(getApplicationContext(),ActivityResult.class));
        getIntent().putExtra(" ",correctCount);
    }

       private void setAllData() {
            Question.setText(modelclass.getQuestion());

            Option1.setText(modelclass.getOptionA());
            Option2.setText(modelclass.getOptionB());
            Option3.setText(modelclass.getOptionC());
            Option4.setText(modelclass.getOptionD());
        }

        public void QuizTimer() {
            new CountDownTimer(600000, 1000) {
                @SuppressLint({"DefaultLocale", "SetTextI18n"})
                public void onTick(long millisUntilFinished) {
                    quizTimer.setText(""+String.format("%d min, %d sec",
                            TimeUnit.MILLISECONDS.toMinutes( millisUntilFinished),
                            TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
                }
                @SuppressLint("SetTextI18n")
                public void onFinish() {
                    quizTimer.setText("done!");
                    startActivity(new Intent(getApplicationContext(),ActivityResult.class));
                    finish();
                }
            }.start();
        }*/

        /*public ArrayList fetchDataForQuiz() {

            ArrayList<dataHolder> ans;

            ans=new ArrayList<>();
            databaseReference = FirebaseDatabase.getInstance().getReference("quizQuestion");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    for(DataSnapshot dataSnapshot:snapshot.getChildren()) {
                        dataHolder dataObj = dataSnapshot.getValue(dataHolder.class);
                        ans.add(dataObj);
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                }
            });

            return ans;
        }*/

        /*public void optAClick(View view) {

            disableButton();
            submit.setClickable(true);

            if(modelclass.getOptionA().equals(modelclass.getCorrectOption())) {
                cardOfA.setCardBackgroundColor(getResources().getColor(R.color.green));
                if(index <list.size()-1) {
                    Correct(cardOfA);
                }
                else {
                    GameWon();
                }
            }
            else {
                Wrong(cardOfA);
            }
        }

        public void optBClick(View view) {

            disableButton();
            submit.setClickable(true);
            if(modelclass.getOptionB().equals(modelclass.getCorrectOption())) {
                cardOfB.setCardBackgroundColor(getResources().getColor(R.color.green));
                if(index <list.size()-1) {
                    Correct(cardOfB);
                }
                else {
                    GameWon();
                }
            }
            else {
                Wrong(cardOfB);
            }
        }

        public void optCClick(View view) {

            disableButton();
            submit.setClickable(true);
            if(modelclass.getOptionC().equals(modelclass.getCorrectOption())) {
                cardOfC.setCardBackgroundColor(getResources().getColor(R.color.green));
                if(index <list.size()-1) {
                    Correct(cardOfC);
                }
                else {
                    GameWon();
                }
            }
            else {
                Wrong(cardOfC);
            }
        }

        public void optDClick(View view) {

            disableButton();
            submit.setClickable(true);
            if(modelclass.getOptionD().equals(modelclass.getCorrectOption())) {
                cardOfD.setCardBackgroundColor(getResources().getColor(R.color.green));
                if(index <list.size()-1) {
                    Correct(cardOfD);
                }
                else {
                    GameWon();
                }
            }
            else {
                Wrong(cardOfD);
            }
        }*/
}