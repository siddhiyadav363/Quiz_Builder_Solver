package siddhiyadav363atgmail.com.quizbuildersolver;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class ActivitySetQuiz extends AppCompatActivity {


    private EditText QuestionNumber,Question,OptionOne,OptionTwo,OptionThree,OptionFour,CorrectOption;

    FirebaseDatabase datBase = FirebaseDatabase.getInstance();

    int counter=1;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_quiz);

        QuestionNumber=findViewById(R.id.EditText_Question_number);
        Question=findViewById(R.id.EditText_Questions);
        OptionOne=findViewById(R.id.EditText_Options_One);
        OptionTwo=findViewById(R.id.EditText_Options_Two);
        OptionThree=findViewById(R.id.EditText_Options_Three);
        OptionFour=findViewById(R.id.EditText_Options_Four);
        CorrectOption=findViewById(R.id.EditText_Correct_Option);

        Button next = findViewById(R.id.btnNext);
        Button submit = findViewById(R.id.btnSubmit);

        next.setOnClickListener(view -> {
            if(counter>4) {
                setQuestion();
                Toast.makeText(ActivitySetQuiz.this,"Question Limit",Toast.LENGTH_SHORT).show();
                Intent k = new Intent(getApplicationContext(),ActivityAdmin.class);
                startActivity(k);
                counter=0;
            }else {
                setQuestion();
                counter++;
            }
        });

        submit.setOnClickListener(view -> {
            setQuestion();
            counter++;
            Intent k = new Intent(getApplicationContext(),ActivityAdmin.class);
            startActivity(k);
        });

        Toast.makeText(getApplicationContext(),"You can add up to 5 Questions ",Toast.LENGTH_LONG).show();
    }

    public void setQuestion() {
        DatabaseReference node = datBase.getReference("quizQuestion");

        String QueNumber = QuestionNumber.getText().toString();
        String Que=Question.getText().toString();
        String OptOne=OptionOne.getText().toString();
        String OptTwo=OptionTwo.getText().toString();
        String OptThree=OptionThree.getText().toString();
        String OptFour=OptionFour.getText().toString();
        String CorrectOpt=CorrectOption.getText().toString();

        dataHolder obj = new dataHolder(Que,OptOne,OptTwo,OptThree,OptFour,CorrectOpt);
        node.child(QueNumber).setValue(obj);

        QuestionNumber.getText().clear();
        Question.getText().clear();
        OptionOne.getText().clear();
        OptionTwo.getText().clear();
        OptionThree.getText().clear();
        OptionFour.getText().clear();
        CorrectOption.getText().clear();

        Toast.makeText(getApplicationContext(),"Questions Add to database ",Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        counter=0;
    }
}